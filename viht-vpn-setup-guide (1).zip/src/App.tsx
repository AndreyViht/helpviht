/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from 'motion/react';
import { 
  Bot, 
  User, 
  AppWindow, 
  Smartphone, 
  ExternalLink, 
  ShieldCheck, 
  Zap, 
  Globe,
  Settings,
  ArrowRight,
  MoveUpRight
} from 'lucide-react';
import { useState } from 'react';

const steps = [
  {
    id: 1,
    title: 'Запустите бота',
    description: 'Перейдите в Telegram бот @VihtVPNbot и введите команду /start для активации.',
    icon: Bot,
    color: 'bg-blue-500',
    action: 'Открыть бота',
    link: 'https://t.me/VihtVPNbot'
  },
  {
    id: 2,
    title: 'Личный кабинет',
    description: 'Бот выдаст вам сообщение с кнопкой «Личный кабинет». Нажмите на неё.',
    icon: User,
    color: 'bg-purple-500',
  },
  {
    id: 3,
    title: 'Подключение устройства',
    description: 'В открывшемся приложении на сайте нажмите на кнопку «Подключить устройство».',
    icon: Smartphone,
    color: 'bg-indigo-500',
  },
  {
    id: 4,
    title: 'Открыть в Happ',
    description: 'Выберите «Открыть в Happ». Если приложение уже скачано, подписка подключится автоматически.',
    icon: AppWindow,
    color: 'bg-cyan-500',
  }
];

const routingSteps = [
  {
    id: 1,
    title: 'Откройте Happ',
    description: 'Запустите приложение Happ на вашем устройстве, которое вы настроили ранее.',
    icon: Smartphone,
    color: 'from-blue-500/20 to-cyan-500/20'
  },
  {
    id: 2,
    title: 'Настройки',
    description: 'В верхнем левом углу основного экрана найдите и нажмите на иконку шестерёнки ⚙️.',
    icon: Settings,
    color: 'from-slate-500/20 to-slate-700/20'
  },
  {
    id: 3,
    title: 'Выбор приложений',
    description: 'Найдите в списке настроек пункт «Прокси для выбранных приложений».',
    icon: AppWindow,
    color: 'from-indigo-500/20 to-purple-500/20'
  },
  {
    id: 4,
    title: 'Активация',
    description: 'Переключите тумблер в режим «ВКЛ» и выберите из списка те сервисы, где нужен VPN.',
    icon: Zap,
    color: 'from-emerald-500/20 to-teal-500/20'
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'connection' | 'routing'>('connection');

  return (
    <div className="min-h-screen bg-[#000205] text-slate-100 font-sans selection:bg-blue-500/40 selection:text-white pt-24 px-4 overflow-x-hidden relative">
      {/* Liquid Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-5%] left-[-10%] w-[50%] h-[50%] bg-blue-600/15 blur-[140px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-5%] w-[40%] h-[40%] bg-indigo-600/10 blur-[120px] rounded-full" />
        <div className="absolute top-[30%] right-[10%] w-[30%] h-[30%] bg-emerald-500/5 blur-[100px] rounded-full" />
      </div>

      {/* Dynamic Island Header */}
      <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 w-full max-w-fit px-4">
        <motion.nav 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="bg-[#0A0A0A]/40 backdrop-blur-[30px] border border-white/10 rounded-full p-1.5 shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex items-center gap-1.5 ring-1 ring-white/10"
        >
          <button
            onClick={() => setActiveTab('connection')}
            className={`px-6 py-2.5 rounded-full text-[13px] font-bold tracking-tight transition-all duration-500 flex items-center gap-2.5 ${
              activeTab === 'connection' 
                ? 'bg-white text-black shadow-[0_4px_15px_rgba(255,255,255,0.3)] scale-100' 
                : 'text-slate-400 hover:text-white hover:bg-white/5 opacity-80'
            }`}
          >
            <ShieldCheck size={16} />
            Подключение
          </button>
          <button
            onClick={() => setActiveTab('routing')}
            className={`px-6 py-2.5 rounded-full text-[13px] font-bold tracking-tight transition-all duration-500 flex items-center gap-2.5 ${
              activeTab === 'routing' 
                ? 'bg-white text-black shadow-[0_4px_15px_rgba(255,255,255,0.3)] scale-100' 
                : 'text-slate-400 hover:text-white hover:bg-white/5 opacity-80'
            }`}
          >
            <Settings size={16} />
            Маршрутизация
          </button>
        </motion.nav>
      </div>

      <main className="relative z-10 max-w-6xl mx-auto pb-24">
        <AnimatePresence mode="wait">
          {activeTab === 'connection' ? (
            <motion.div
              key="connection"
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -10 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
            >
              {/* Hero Section */}
              <header className="text-center mb-20 md:mb-28 pt-12">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[13px] font-bold tracking-wide uppercase mb-8 shadow-lg shadow-blue-500/5">
                  <ShieldCheck size={14} />
                  Безопасный доступ
                </div>
                <h1 className="text-5xl md:text-8xl font-display font-black tracking-tight mb-8 bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-slate-500 leading-[1.1]">
                  Viht <span className="text-blue-500">VPN</span>
                </h1>
                <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
                  Простая настройка вашего безопасного соединения в 4 быстрых шага.
                </p>
              </header>

              {/* Steps Layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-24">
                {steps.map((step, index) => (
                  <motion.div
                    key={step.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="relative group overflow-hidden"
                  >
                    <div className="p-8 rounded-[40px] bg-white/[0.03] border border-white/10 backdrop-blur-3xl h-full flex flex-col transition-all duration-500 group-hover:bg-white/[0.06] group-hover:border-white/20 group-hover:-translate-y-1">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500/20 to-indigo-600/20 flex items-center justify-center text-blue-400 border border-white/5 mb-8 transition-transform duration-500 group-hover:scale-110">
                        <step.icon size={24} />
                      </div>
                      
                      <div className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em] mb-4 opacity-70">
                        Блок {step.id}
                      </div>
                      
                      <h3 className="text-xl font-bold mb-4 text-white leading-tight">
                        {step.title}
                      </h3>
                      
                      <p className="text-slate-400 text-sm leading-relaxed mb-8 flex-grow">
                        {step.description}
                      </p>

                      {step.link && (
                        <a 
                          href={step.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-auto group/btn inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-blue-600 text-white text-sm font-bold transition-all hover:bg-blue-500 hover:shadow-xl hover:shadow-blue-500/20 active:scale-95"
                        >
                          {step.action}
                          <MoveUpRight size={16} className="group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
                        </a>
                      )}

                      {/* Internal Highlight Line */}
                      <div className="absolute top-0 left-12 right-12 h-[1px] bg-gradient-to-r from-transparent via-blue-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Enhanced CTA Footer */}
              <div className="mt-12 p-8 md:p-12 rounded-[50px] bg-gradient-to-br from-blue-600/10 to-indigo-600/5 border border-white/5 backdrop-blur-3xl relative overflow-hidden group shadow-2xl">
                <div className="absolute inset-0 bg-white/[0.02] opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                <div className="flex flex-col md:flex-row items-center justify-between gap-12 relative z-10">
                  <div className="max-w-lg text-center md:text-left">
                    <div className="flex items-center justify-center md:justify-start gap-2 text-xs text-emerald-400 font-bold uppercase tracking-widest mb-4">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      Система активна
                    </div>
                    <h2 className="text-3xl md:text-5xl font-black text-white mb-6 leading-tight">
                      Начните в <br className="hidden md:block" /> Telegram сегодня.
                    </h2>
                    <p className="text-slate-400 text-sm md:text-base leading-relaxed">
                      Присоединяйтесь к тысячам пользователей, которые выбрали стабильность и приватность.
                    </p>
                  </div>
                  
                  <div className="flex flex-col gap-4 w-full md:w-auto">
                    <a 
                      href="https://t.me/VihtVPNbot"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-10 py-5 rounded-[24px] bg-white text-black text-base font-black hover:bg-blue-50 transition-all flex items-center justify-center gap-3 shadow-xl hover:-translate-y-1 active:translate-y-0"
                    >
                      Запустить @VihtVPNbot
                      <ArrowRight size={20} />
                    </a>
                    <a 
                      href="https://t.me/anviht"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-10 py-5 rounded-[24px] bg-white/5 border border-white/10 text-white text-sm font-bold backdrop-blur-xl hover:bg-white/10 transition-all text-center"
                    >
                      ТГ поддержка @anviht
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="routing"
              initial={{ opacity: 0, scale: 0.98, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98, y: -10 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
            >
              {/* Routing Header */}
              <header className="text-center mb-20 md:mb-28 pt-12">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[13px] font-bold tracking-wide uppercase mb-8 shadow-lg shadow-emerald-500/5">
                  <Settings size={14} className="animate-spin-slow" />
                  Умная маршрутизация
                </div>
                <h1 className="text-5xl md:text-8xl font-display font-black tracking-tight mb-8 bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-slate-500 leading-[1.1]">
                  Split <span className="text-emerald-500">Tunneling</span>
                </h1>
                <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
                  Настройте VPN только для выбранных приложений, чтобы всё остальное работало напрямую.
                </p>
              </header>

              {/* Routing Steps */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-16">
                {routingSteps.map((step, index) => (
                  <motion.div
                    key={step.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="relative group overflow-hidden"
                  >
                    <div className="p-8 rounded-[40px] bg-white/[0.03] border border-white/10 backdrop-blur-3xl h-full flex flex-col transition-all duration-500 group-hover:bg-white/[0.06] group-hover:border-white/20 group-hover:-translate-y-1">
                      <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center text-white border border-white/5 mb-8 transition-transform duration-500 group-hover:scale-110`}>
                        <step.icon size={22} />
                      </div>
                      
                      <div className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-4 opacity-70 font-mono">
                        Инструкция {step.id}
                      </div>
                      
                      <h3 className="text-xl font-bold mb-4 text-white leading-tight">
                        {step.title}
                      </h3>
                      
                      <p className="text-slate-400 text-sm leading-relaxed flex-grow">
                        {step.description}
                      </p>

                      <div className="absolute top-0 left-12 right-12 h-[1px] bg-gradient-to-r from-transparent via-emerald-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Result Badge */}
              <div className="max-w-4xl mx-auto p-1 border border-white/5 rounded-[42px] bg-white/[0.02] mb-24">
                <div className="bg-emerald-500/5 backdrop-blur-xl border border-emerald-500/10 rounded-[40px] p-8 md:p-12 flex flex-col md:flex-row items-center gap-8 text-center md:text-left">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 shadow-lg shadow-emerald-500/10">
                    <ShieldCheck size={32} />
                  </div>
                  <div>
                    <h4 className="text-2xl font-bold text-white mb-2">Идеальный результат</h4>
                    <p className="text-slate-400 leading-relaxed">
                      У вас другие сервисы ругаться не будут на VPN, а те которые вы выбрали будут работать через него. 
                      Нет необходимости каждый раз включать и отключать соединение.
                    </p>
                  </div>
                </div>
              </div>

              {/* Support CTA Reusable */}
              <div className="mt-12 p-8 md:p-12 rounded-[50px] bg-gradient-to-br from-blue-600/10 to-indigo-600/5 border border-white/5 backdrop-blur-3xl relative overflow-hidden group shadow-2xl">
                <div className="absolute inset-0 bg-white/[0.02] opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                <div className="flex flex-col md:flex-row items-center justify-between gap-12 relative z-10">
                  <div className="max-w-lg text-center md:text-left">
                    <div className="flex items-center justify-center md:justify-start gap-2 text-xs text-blue-400 font-bold uppercase tracking-widest mb-4">
                      Нужна помощь?
                    </div>
                    <h2 className="text-3xl md:text-5xl font-black text-white mb-6 leading-tight">
                      Мы всегда <br className="hidden md:block" /> на связи.
                    </h2>
                    <p className="text-slate-400 text-sm md:text-base leading-relaxed">
                      Если у вас возникли трудности с настройкой, наша команда поддержки поможет вам в любое время.
                    </p>
                  </div>
                  
                  <div className="flex flex-col gap-4 w-full md:w-auto">
                    <a 
                      href="https://t.me/VihtVPNbot"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-10 py-5 rounded-[24px] bg-white text-black text-base font-black hover:bg-blue-50 transition-all flex items-center justify-center gap-3 shadow-xl hover:-translate-y-1 active:translate-y-0"
                    >
                      Бот в Telegram
                      <ArrowRight size={20} />
                    </a>
                    <a 
                      href="https://t.me/anviht"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-10 py-5 rounded-[24px] bg-white/5 border border-white/10 text-white text-sm font-bold backdrop-blur-xl hover:bg-white/10 transition-all text-center"
                    >
                      ТГ поддержка @anviht
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <footer className="mt-20 text-center">
          <a 
            href="https://anviht.ru" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-[10px] text-slate-700 font-bold uppercase tracking-[0.4em] px-4 hover:text-blue-500 transition-colors duration-300"
          >
            help Viht VPN | by 2025
          </a>
        </footer>
      </main>
      
      <style>{`
        .animate-spin-slow {
          animation: spin 8s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}


